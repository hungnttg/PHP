<?php
    $host='localhost';
    $user='root';
    $pass='sesame';
    $conn = new mysqli($host,$user,$pass);
    if($conn->connect_error)
    {
        die ('Ket noi khong thanh cong: '.$conn->connect_error);
    }
    else
    {
        echo 'Ket noi thanh cong';
    }
?>