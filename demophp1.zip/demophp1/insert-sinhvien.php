<?php
    $host='localhost';
    $user='root';
    $pass='sesame';
    $db='php';
    $conn = new mysqli($host,$user,$pass,$db);
    if($conn->connect_error)
    {
        die('Ket noi that bai: '.$conn->connect_error);
    }
    else
    {
        $sql = "INSERT INTO sinhvien VALUES ('ph002','Tran Van B','Ha Noi')";
        if($conn->query($sql))
        {
            echo 'Them du lieu thanh cong';
        }
        else
        {
            echo 'Them du lieu that bai: '.$conn->error;
        }
    }
?>