<?php
    $conn = new mysqli('localhost','root','sesame','mma');
    $sql = "INSERT INTO Customer VALUES (3,'Vu Van C','02222222','Dong Quan')";
    if($conn->query($sql))
    {
        echo 'Insert thanh cong';
    }
?>