<?php
    $a=5;
    $b=10;
    $c= $a+$b;
    $hieu = $a-$b;
    $tich = $a*$b;
    $thuong = $a/$b;
    echo 'Tong cua a='.$a.' va b='.$b.' la '.$c."<br>";
    echo 'Hieu cua a='.$a.' va b='.$b.' la '.$hieu."<br>";
    echo 'Tich cua a='.$a.' va b='.$b.' la '.$tich."<br>";
    echo 'Thuong cua a='.$a.' va b='.$b.' la '.$thuong."<br>";
?>