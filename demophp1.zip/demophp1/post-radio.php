<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Radio</title>
</head>
<body>
    <h1>Post du lieu</h1>
    <form action="" method="POST">
        Gioi tinh: <input type="radio" name="radGt" value="Nam" checked="checked"/> Nam <br>
         <input type="radio" name="radGt" value="Nu" /> Nu <br>
        
        So thich:<br>
        <input type="checkbox" name="cbxAnChoi" value="An choi"/>An choi <br>
        <input type="checkbox" name="cbxNhayMua" value="Nhay Mua"/> Nhay mua <br>
        <input type="checkbox" name="cbxTieuTien" value="Tieu tien"/> Tieu tien <br> 

         <input type="submit" name="submit" value="submit"/>


    </form>
    <?php
        if(isset($_POST['submit']))
        {
            $gt = $_POST['radGt'];
            $sothich=array();//khai bao mang
            if(isset($_POST['cbxAnChoi']))
            {//them phan tu vao mang
                array_push($sothich, $_POST['cbxAnChoi']);
            }
            if(isset($_POST['cbxNhayMua']))
            {
                array_push($sothich, $_POST['cbxNhayMua']);
            }
            if(isset($_POST['cbxTieuTien']))
            {
                array_push($sothich, $_POST['cbxTieuTien']);
            }
            echo "Gioi tinh la: ".$gt."<br>";
            //print_r($sothich);
            foreach($sothich as $key=>$value)
            {
                echo $key."--".$value;
            }
        }
    ?>
</body>
</html>