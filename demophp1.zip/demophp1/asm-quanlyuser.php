<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Quan ly user</title>
</head>
<body>
    <h1>Quan ly user</h1>
    <form action="" method="post">
        User Name <input type="text" name="txtUser" value=""/><br>
        Pass <input type="password" name="txtPass" value=""/><br>
        Email <input type="text" name="txtEmail" value=""/><br>
        Is Admin <input type="text" name="txtIsAdmin" value=""/><br>
        <input type="submit" name="action" value="Add"/>
    </form>
    <?php
    if(isset($_POST['action']))
    {
        //lay du lieu duoc gui den tu server
        $user = $_POST['txtUser'];
        $pass = $_POST['txtPass'];
        $email = $_POST['txtEmail'];
        $isAdmin = $_POST['txtIsAdmin'];
        //ket noi voi csdl
        $conn = new mysqli('localhost','root','sesame','asm');
        //kiem tra xem ket noi co bi loi khong
        if($conn->connect_error)
        {
            die('Co loi ket noi: '.$conn->connect_error);
        }
        else//neu khong loi
        {
            //khai bao chuoi insert
            $sql = "INSERT INTO user VALUES ('".$user."','".$pass."','".$email."',".$isAdmin.")";
            $conn->query($sql);
            echo 'Insert thanh cong';
            
        }
        $conn->close();
    }
    ?>
</body>
</html>