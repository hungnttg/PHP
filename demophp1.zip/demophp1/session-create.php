<?php
session_start();
    $_SESSION['cart']='ss-cart';//tao 1 session name: cart; value=ss-cart
    $s = $_SESSION['cart'];
    echo $s;
    session_write_close();
?>