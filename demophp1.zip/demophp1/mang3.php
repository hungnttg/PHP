<?php
    $mang =array('a'=>10,'b'=>20,'3'=>50,'c'=>-2);
    ksort($mang);
    foreach($mang as $key=>$value)
    {
        echo $key."=>". $value."<br>";
    }
?>