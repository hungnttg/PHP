<!doctype html>
<?php
session_start();
    require_once('SanPhamDB.php');//tham chieu
    global $result;
?>
<html lang="en">
  <head>
      
    <title>Admin</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
  </head>
  <body>
      
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
    <div class="jumbotron text-center">
        <h1 class="display-4">Trang admin </h1>
        <p class="lead">San pham</p>
        <hr class="my-4">
        <div class="card-columns">
            <div class="card">
                <img class="card-img-top" src="holder.js/100x180/" alt="">
                <div class="card-body">
                    <h4 class="card-title">Them du lieu</h4>
                    <form action="" method="post">
                        <div class="form-group">
                          <label for="">Ma SP</label>
                          <input type="text" class="form-control" name="txtMaSP" id="txtMaSP" aria-describedby="helpId" placeholder="" value=""> 
                        </div>
                        <div class="form-group">
                          <label for="">Ten SP</label>
                          <input type="text" class="form-control" name="txtTenSP" id="txtTenSP" aria-describedby="helpId" placeholder="">
                          
                        </div>
                        <div class="form-group">
                          <label for="">DVT</label>
                          <input type="text" class="form-control" name="txtDVT" id="txtDVT" aria-describedby="helpId" placeholder=""> 
                        </div>
                        <div class="form-group">
                          <label for="">DonGia</label>
                          <input type="text" class="form-control" name="txtDonGia" id="txtDonGia" aria-describedby="helpId" placeholder=""> 
                        </div>
                        <div class="form-group">
                          <label for="">NCC</label>
                          <input type="text" class="form-control" name="txtNCC" id="txtNCC" aria-describedby="helpId" placeholder=""> 
                        </div>
                        <button type="submit" class="btn btn-primary" name="btnThem" value="btnThem">Them</button>
                        <button type="submit" class="btn btn-primary" name="btnHienThi" value="btnHienThi">Hien Thi</button>
                        <button type="submit" class="btn btn-primary" name="btnUpdate" value="btnUpdate">Update</button>
                    </form>
                </div>
            </div>
            <div class="card">
                <img class="card-img-top" src="holder.js/100x180/" alt="">
                <div class="card-body">
                    <h4 class="card-title">Hien thi du lieu</h4>
                    <table class="table">
                        <thead>
                            <tr>
                                <th>MaSP</th>
                                <th>TenSP</th>
                                <th>DVT</th>
                                <th>DonGia</th>
                                <th>NCC</th>
                                <th>...</th>
                                <th>...</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                                if(isset($_POST['btnHienThi']))
                                {
                                   $result= hienThiSanPhamDB();
                                   while($row=$result->fetch_assoc())
                                    {
                                        echo '<tr>';
                                        echo '<td>'.$row['MaSP'].'</td>';
                                        echo '<td>'.$row['TenSP'].'</td>';
                                        echo '<td>'.$row['DVT'].'</td>';
                                        echo '<td>'.$row['DonGia'].'</td>';
                                        echo '<td>'.$row['NCC'].'</td>';
                                        echo '<td>';
                                        echo '<form action="" method="post">';
                                        echo '<button type="submit" class="btn btn-primary" name="btnSua" value="'.$row['MaSP'].'">Sua</button>';
                                        echo '</form>';
                                        echo '</td>';
                                        echo '<td>';
                                        echo '<form action="" method="post">';
                                        echo '<button type="submit" class="btn btn-primary" name="btnXoa" value="'.$row['MaSP'].'">Xoa</button>';
                                        echo '</form>';
                                        echo '</td>';

                                        echo '<td>';
                                        echo '<form action="" method="post">';
                                        echo '<button type="submit" class="btn btn-primary" name="btnAddCart" value="'.$row['MaSP'].'">Add Cart</button>';
                                        echo '</form>';
                                        echo '</td>';

                                        echo '</tr>';
                                    }
                                    
                                }
                            ?>
                            
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <?php
        if(isset($_POST['btnThem']))
        {
            $MaSP = $_POST['txtMaSP'];
            $TenSP = $_POST['txtTenSP'];
            $DVT = $_POST['txtDVT'];
            $DonGia = $_POST['txtDonGia'];
            $NCC  = $_POST['txtNCC'];
            $i= themSanPhamDB($MaSP,$TenSP,$DVT,$DonGia,$NCC);
            if($i<0)
            {
                echo "Them that bai";
            }
            else
            {
                echo "Them thanh cong";
            }
        }
        if(isset($_POST['btnSua']))
        {
            $MaSP = $_POST['btnSua'];
            $resultOne=hienThiSanPhamDBTheoID($MaSP);
            while($rowOne = $resultOne->fetch_assoc())
            {
                //su dung javasctipt dien du lieu
                echo '<script type="text/JavaScript">document.getElementById("txtMaSP").value="'.$rowOne['MaSP'].'";</script>';
                echo '<script type="text/JavaScript">document.getElementById("txtTenSP").value="'.$rowOne['TenSP'].'";</script>';
                echo '<script type="text/JavaScript">document.getElementById("txtDVT").value="'.$rowOne['DVT'].'";</script>';
                echo '<script type="text/JavaScript">document.getElementById("txtDonGia").value="'.$rowOne['DonGia'].'";</script>';
                echo '<script type="text/JavaScript">document.getElementById("txtNCC").value="'.$rowOne['NCC'].'";</script>';
            }

            

        }
        if(isset($_POST['btnXoa']))
        {
            $MaSP = $_POST['btnXoa'];

            $isXoa= xoaSanPhamDB($MaSP);
            if(!$isXoa)
            {
                echo "Xoa that bai";
            }
            else
            {
                echo "Xoa thanh cong";
            }
        }
        if(isset($_POST['btnUpdate']))
        {
            $MaSP = $_POST['txtMaSP'];
            $TenSP = $_POST['txtTenSP'];
            $DVT = $_POST['txtDVT'];
            $DonGia = $_POST['txtDonGia'];
            $NCC  = $_POST['txtNCC'];
            $isUpdate= updateSanPhamDB($MaSP,$TenSP,$DVT,$DonGia,$NCC);
            if(!$isUpdate)
            {
                echo "Update that bai";
            }
            else
            {
                echo "Update thanh cong";
            }
        }

        if(isset($_POST['btnAddCart']))//them du lieu vao gio hang
        {
            //session_start();
            $MaSP = $_POST['btnAddCart'];//lay ma san pham
            if(!isset($_SESSION['cart']))//kiem tra ton tai gio hang
            {
                $_SESSION['cart']=array();//tao gio hang
            }
            if(!isset($_SESSION['cart'][$MaSP]))//kiem tra sp ton tai k
            {
                $_SESSION['cart'][$MaSP]['sl']=1;//gan so luong cua SP la 1
            }
            else
            {
                $_SESSION['cart'][$MaSP]['sl']+=1;//neu ton tai, cong them 1
            }
            //in ra gio hang
            echo "<pre>";
            print_r($_SESSION['cart']);
            echo "</pre>";
            // foreach($_SESSION['cart'] as $key=>$value)
            // {
            //     echo $key."-".$value['sl']."<br>";
            // }
            
        }
        
    ?>
</body>
</html>