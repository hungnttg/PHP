<?php
    function ketNoiDB()
    {//sesame la password tren may minh; cac ban de trong nhe
        return new mysqli('localhost','root','sesame','asm');
    }
    function themSanPhamDB($MaSP,$TenSP,$DVT,$DonGia,$NCC)
    {
        $con = ketNoiDB();
        $i=$con->query('INSERT INTO SanPham VALUES ("'.$MaSP.'","'.$TenSP.'","'.$DVT.'",'.$DonGia.',"'.$NCC.'")');
        return $i;
    }
    function hienThiSanPhamDB()
    {
        $con=ketNoiDB();
        $result = $con->query('SELECT * FROM SanPham');
        return $result;
    }
    function xoaSanPhamDB($MaSP)
    {
        $con = ketNoiDB();
        $i=$con->query('DELETE FROM SanPham WHERE MaSP="'.$MaSP.'" ');
        return $i;
    }

    function hienThiSanPhamDBTheoID($MaSP)
    {
        $con=ketNoiDB();
        $resultOne = $con->query('SELECT * FROM SanPham WHERE MaSP = "'.$MaSP.'"');
        return $resultOne;
    }

    function updateSanPhamDB($MaSP,$TenSP,$DVT,$DonGia,$NCC)
    {
        $con = ketNoiDB();
        $i=$con->query('UPDATE SanPham SET TenSP="'.$TenSP.'",DVT="'.$DVT.'",DonGia="'.$DonGia.'",NCC="'.$NCC.'" WHERE MaSP="'.$MaSP.'" ');
        return $i;
    }

?>