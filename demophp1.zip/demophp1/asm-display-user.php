<?php
//ket noi CSDL
$con = new mysqli('localhost','root','sesame','asm');
$result=$con->query("SELECT * FROM user");
if($result->num_rows>0)//kiem tra so dong
{
    echo '<table border="1"><tr><td>Username</td><td>Email</td></tr>';
    while($row=$result->fetch_assoc())//doc du lieu theo dong
    {
        echo '<tr><td>'.$row['username'].'</td><td>'.$row['email'].'</td></tr>';
        
    }
    echo '</table>';
}
?>