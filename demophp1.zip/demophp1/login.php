<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Login</title>
    <script type="text/javascript">
        function checkLogin()
        {
           if(document.getElementById("txtUser").value =="")
           {
               alert("Phai nhap du lieu vao truong user");
               return false;
           }
           if(document.getElementById("txtPass").value =="")
           {
               alert("Phai nhap du lieu vao truong pass");
               return false;
           }

        }
    </script>
</head>
<body>
    <h2>Login form</h2>
    <form action="" method="post" name="frm" onsubmit="return checkLogin();">
        User <input type="text" name="txtUser" id="txtUser" value=""/><br>
        Pass <input type="password" name="txtPass" id="txtPass" value=""/><br>
        <input type="submit" name="btnLogin" value="login" />
    </form>
    <?php
        if(isset($_POST['btnLogin']))
        {
            $user = $_POST['txtUser'];
            $pass = $_POST['txtPass'];
            $conn = new mysqli('localhost','root','sesame','test1');
            $str = "SELECT * FROM user WHERE username='$user' and password='$pass'";
            $result=$conn->query($str);
            if($result->num_rows>0)
            //if($user=="Admin" && $pass=="123456" )
            {
                echo "Dang nhap thanh cong";
                header("location: http://localhost/demophp1/chao.html");
                
            }
            else { echo "Dang nhap khong thanh cong";}
        }
    ?>
</body>
</html>