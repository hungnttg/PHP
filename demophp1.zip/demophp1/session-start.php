<?php //khoi tao session
    session_set_cookie_params(100000,'/');
    session_start();
?>