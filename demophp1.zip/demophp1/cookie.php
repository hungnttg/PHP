<?php
    $user = 'userid';
    $pass='userpass';
    setcookie($user ,'annv',strtotime('+1 year'),'/');//set
    setcookie($pass,'123456',strtotime('+1 year'),'/');

    $userid=$_COOKIE['userid'];//get
    echo 'Ban vua luu cookie co userid la: '.$userid."<br/>";
    echo 'pass la: '.$_COOKIE['userpass'];
?>