<?php
    $date=new DateTime('last day of 2020-2');
    echo $date->format('Y-m-d');
?>