<?php
    $age=array("1204"=>"33.1500","1199"=>"16.83","1176"=>"11.73");
    ksort($age);
    
    foreach($age as $x=>$x_value)
       {
        echo "Value=" . $x_value;
        echo "<br>";
       }
?>