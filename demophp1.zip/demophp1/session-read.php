<?php
session_start();
        echo session_name();
        echo session_id();
    //if(isset($_SESSION['cart1']))
    //{
        $cart1 = $_SESSION['cart1'];
        foreach($cart1 as $item)
        {
            echo $item;
        }
    //}
    //if(isset($_SESSION['cart']))
    //{
        echo $_SESSION['cart'];
    //}
    echo '<pre>';
    var_dump($_SESSION);
    echo '</pre>';
    echo '<pre>' . print_r($_SESSION, TRUE) . '</pre>';
?>