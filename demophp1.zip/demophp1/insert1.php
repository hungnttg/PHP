<?php
$conn = new mysqli('localhost','root','sesame','asm');
$sql = "INSERT INTO user VALUES ('NguyenVanA','123456','a@aaa.com',0)";
$conn->query($sql);
?>