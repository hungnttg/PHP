<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <h2>Insert du lieu</h2>
    <form action="" method="post">
        Code <input type="text" name="txtCode" value=""/><br/>
        Name <input type="text" name="txtName" value=""/><br>
        price <input type="text" name="txtPrice" value=""/><br>
        <input type="submit" value="Insert" name="btnInsert"/>
    </form>
    <?php
        require_once('ProductDB.php');
        if(isset($_POST['btnInsert']))
        {
            $code = $_POST['txtCode'];
            $name=$_POST['txtName'];
            $price = $_POST['txtPrice'];
        $p = new ProductDB();
        $i=$p->insertProduct1($code,$name,$price);
        if($i)
        {
            echo "Insert thanh cong";
        }
        else
        {
            echo "Insert that bai";
        }
        }
    ?>
</body>
</html>