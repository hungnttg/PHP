<?php
class ProductDB
{
    var $code;
    var $name;
    var $price;
    function __construct(){}
    function connectDB()
    {
        $db= new mysqli('localhost','root','sesame','DB');
        return $db;
    }
    function insertProduct($code,$name,$price)
    {
        $db = $this->connectDB();//lay ve ket noi 
        // $strInsert = "INSERT INTO Product 
        // VALUES ('".$code."','".$name."',".$price.")";
        // $i=$db->query($strInsert);
        // return $i;
        $strInsert  = "INSERT INTO Product VALUES (?,?,?)";
        $stm=$db->prepare($strInsert);//chuan bi cau lenh in sert
        //string: s
        //double: d
        //integer: i
        $stm->bind_param('ssd',$code,$name,$price);//gan tham so
        $i = $stm->execute();//thuc thi cau lenh

    }
    function insertProduct1($code,$name,$price)
    {
        $db = $this->connectDB();
        $strInsert  = "INSERT INTO Product VALUES (?,?,?)";
        $stm=$db->prepare($strInsert);
        $stm->bind_param('ssd',$code,$name,$price);
        $i = $stm->execute();
        return $i;

    }

}
?>