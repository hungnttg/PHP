<?php
    //ham lay thong tin phien ban
    phpinfo();
?>