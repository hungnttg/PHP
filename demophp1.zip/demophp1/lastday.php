<?php
$date = new DateTime('first day of 2020-2');
echo $date->format('Y-m-d');
?>