<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Checkbox</title>
</head>
<body>
    <form action="" method="post">
        So thich: <br>
        <input type="checkbox" name="cbxSoThich[]" 
        value="anchoi" checked="checked"/> An choi <br>
        <input type="checkbox" name="cbxSoThich[]" 
        value="nhaymua" /> Nhay mua <br>
        <input type="checkbox" name="cbxSoThich[]" 
        value="tieutien" /> Tieu tien <br>
        <input type="submit" value="submit" name="submit"/>
    </form>
    <?php
        if(isset($_POST['submit']))
        {
            if(isset($_POST['cbxSoThich']))
            {
                $sothich=$_POST['cbxSoThich'];
                echo "So thich la: ";
                foreach($sothich as $key=>$value)
                {
                    echo $value."<br>";
                }
            }
        }
    ?>
</body>
</html>