<?php
    $mang = array('abc','abxc','aa','aaaaaaaaaaaa');
    $dodai = array_map('strlen',$mang);
    echo 'Do dai nho nhat: '. min($dodai)."<br>";
    echo 'Do dai lon nhat: '. max($dodai)."<br>";
?>