<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Read cookie</title>
</head>
<body>
<form action="" method="post">
    User <input type="text" name="txtUser" 
value="<?php if(isset($_POST['btnSubmit'])){echo $_COOKIE['userid'];}?>"/><br>
    Pass <input type="text" name="txtPass" 
value="<?php if(isset($_POST['btnSubmit'])){echo $_COOKIE['userpass'];}?>"/><br>
    <input type="submit" name="btnSubmit" value="read"/>
    </form>
    <?php
    if(isset($_POST['btnSubmit']))
    {
        $user = $_COOKIE['userid'];
        $pass = $_COOKIE['userpass'];

    }
    ?>
</body>
</html>