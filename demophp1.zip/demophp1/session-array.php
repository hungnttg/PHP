<?php
    if(!isset($_SESSION['cart1']))
    {
        $_SESSION['cart1']=array();//tao session la 1 mang
        //dua du lieu vao mang
        $_SESSION['cart1']['key1']='value1';
        $_SESSION['cart1']['SanPham2']='Kem Danh Rang';
        $_SESSION['cart1']['SanPham3']='Nuoc Rua Bat';
        $_SESSION['cart1']['SanPham4']='Khan Mat';

        //doc du lieu tu session
        $cart1 = $_SESSION['cart1'];
        foreach($cart1 as $key=> $item)
        {
            echo $key.": ".  $item."<br>";
        }
        session_write_close();

        print_r($_SESSION);
    }
?>