<?php
    $diem=6.2;
    if($diem<5){
        echo 'Yeu';
    }
    else if($diem<6.5){
        echo 'TB';
    }else if($diem<7.5){
        echo 'Kha';
    } else if($diem<9){
        echo 'Gioi';
    }else{
        echo 'Xuat sac';
    }
?>