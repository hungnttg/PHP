<?php
    function pheptinh($pt,$a,$b){
        if($pt=='+'){
            return $a+$b;
        } else if($pt=='-'){
            return $a-$b;
        } else if($pt=='*'){
            return $a*$b;
        } else if($pt=='/'){
            if($b!=0){
                return $a/$b;
            } else {
                echo 'Khong the chia cho 0';
            }
        }
    }
    $cong = pheptinh('+',3,2);
    $tru = pheptinh('-',3,2);
    $nhan = pheptinh('*',3,2);
    $chia = pheptinh('/',3,2);
    echo 'Cong: '.$cong."<br>";
    echo 'Tru: '.$tru."<br>";
    echo 'Nhan: '.$nhan."<br>";
    echo 'Chia: '.$chia."<br>";
?>