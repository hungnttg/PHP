<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Post du lieu</title>
</head>
<body>
    <form method="post" action="">
        <input type="text" name="txtHeSoA" value=""/><br>
        <input type="text" name="txtHeSoB" value=""/><br>
        <input type="submit" name="btnNghiem" value="Nghiem PT"/>

    </form>
    <?php
        //kiem tra xem button btnNghiem co duoc click hay khong
        if(isset($_POST['btnNghiem']))
        {
            //lay ve he so A
            $a=$_POST['txtHeSoA'];
            //lay ve he so B
            $b=$_POST['txtHeSoB'];
           if($a==0){
               if($b==0){
                    echo 'Phuong trinh vo so nghiem';
                } else {
                    echo 'Phuong trinh vo nghiem';
                }
           }
           else
           {
               $x=-$b/$a;
               echo 'Nghiem cua phuong trinh la: '.$x;
           }
        }
    ?>
</body>
</html>