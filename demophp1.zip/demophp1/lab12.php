<?php
    //ham boc tach cac thanh phan duong link web: parse_url
    $url = 'https://vnexpress.net/bong-da/brazil-vo-dich-copa-america-2019-3949109.html';
    $a = parse_url($url);
    echo " Scheme: ".$a['scheme']."<br>"; //giao thuc
    echo " Path: ".$a['path']."<br>";//duong dan
    echo " Host: ".$a['host']."<br>";//ten host

?>