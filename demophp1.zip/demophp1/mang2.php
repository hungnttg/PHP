<?php
    $array = array('1'=>5,'2'=>10,'3'=>16,'4'=>-1);
    $a=array_filter($array);
    $tb = array_sum($a)/count($a);
    echo "Trung binh mang la: ".$tb;
    $value = max($array);//lay ve gia tri lon nhat
    $key = array_search(max($array),$array);//gia tri max cua key
    echo "Gia tri lon nhat la ".$value." thuoc key: ".$key;
?>