<?php
    $sever='localhost';
    $user='root';
    $pass='sesame';
    $conn = new mysqli($sever,$user,$pass);
    if($conn->connect_error)
    {
        die("Connection failed: ".$conn->connect_error );
    }
    else
    {
        echo 'Connect sucessfully';
    }
?>